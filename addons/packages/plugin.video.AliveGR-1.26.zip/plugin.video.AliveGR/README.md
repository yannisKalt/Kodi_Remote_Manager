# = AliveGR Kodi addon git repository =
## Your one addon for everything greek related

![](https://bitbucket.org/thgiliwt/repo.thgiliwt/raw/HEAD/_thgiliwt/plugin.video.AliveGR/icon.png)

- Live TV
- Radio
- Video on demand
- News
- Movies
- Kids
- Documentaries (Temporarily disabled)
- Sports
- Music on demand
- TV Series & TV Shows
- Short Films

**Primary OSes tested:**

- Windows 10 64 bit
- Debian Linux 64 bit
- Android 7.1.2 & 4.2.2

**Kodi Versions tested:**

- Jarvis 16.1 (deprecated)
- Krypton 17.6 (current primary platform)
- Leia 18.0 RC (x64, _reuselanguageinvoker_ set to __true__)

**Repository zip for updates:**

[repository.thgiliwt-1.6.0.zip](https://bitbucket.org/thgiliwt/plugin.video.alivegr/downloads/repository.thgiliwt-1.6.0.zip "Repo ZIP")

**Source url for the same zip to add into Kodi's file manager sources:**

[http://alivegr.net/master](http://alivegr.net/master "Repo ZIP")

It also has many tools and settings so that you can tweak your viewing experience.
**Have fun.**
Artwork is made by me. Icons were layered with existing flat icons from
######Flaticon.com: [Link](http://www.flaticon.com/ "Flaticon.com")
