class ApiCollection:
    items = []
    next_href = ""
