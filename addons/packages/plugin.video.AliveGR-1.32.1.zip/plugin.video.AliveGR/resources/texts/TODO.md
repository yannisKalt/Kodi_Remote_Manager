# Size indicates importance



##### Fix proxy enabler

---

###### Finish keymap for remote

---

## Complete Python 3 support

---

##### Add search as actor/director

---

### Replace google with native greek-movies as agent for searches

---

#### Add search music

---

#### Implement resolver for STAR

---

## Enhance kineskop resolver by looping the streams

---

#### Overhaul stream picker functions

---

##### Add pseudo live streams or items

---

#### Add genre info on top 50 tracks directory

---

### Add menu item for uploading debug log

---

#### Add version number in welcome prompt

---

### Add main menu item for live movies & pseudo live
